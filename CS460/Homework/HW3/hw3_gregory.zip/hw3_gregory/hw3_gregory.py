#!/usr/bin/env python

import rospy
from geometry_msgs.msg import Twist
from turtlesim.msg import Pose
from turtlesim.srv import TeleportAbsolute
from std_srvs.srv import Empty as EmptyServiceCall
from PID_controller import PID

# Name: Stephen Gregory
# Type: Undergraduate
# CWID: 11812663

class TurtleBot:

    def __init__(self):
        # Creates a node with name 'turtlebot_controller' and make sure it is a
        # unique node (using anonymous=True).
        rospy.init_node('turtlebot_controller', anonymous=True)

        # Publisher which will publish to the topic '/turtle1/cmd_vel'.
        self.velocity_publisher = rospy.Publisher('/turtle1/cmd_vel',
                                                  Twist, queue_size=10)

        self.turtle2_teleport = rospy.ServiceProxy('turtle1/teleport_absolute', TeleportAbsolute)
        self.clear_background = rospy.ServiceProxy('clear', EmptyServiceCall)

        # A subscriber to the topic '/turtle1/pose'. self.update_pose is called
        # when a message of type Pose is received.
        self.pose_subscriber = rospy.Subscriber('/turtle1/pose',
                                                Pose, self.update_pose)

        # Initialize the Pose and the previous Pose
        self.pose = Pose()

        # Initialize the PID controller
        self.pid = PID()
        self.pid.setSetPoint(0)

        self.rate = rospy.Rate(10)

    def update_pose(self, data):
        """
        Callback function called when a new Pose message is received by the subscriber to the topic '/turtle1/pose'
        """
        self.pose = data
        self.pose.x = round(self.pose.x, 4) 
        self.pose.y = round(self.pose.y, 4)

        # The following function is used to add a small amount of noise 
        self.applyMomentum(self.pose.x, 5, self.pose.theta, self.pose.linear_velocity)

    
    def applyMomentum(self, x, y, z, mag):
        # adds noise to robot position
        robot.turtle2_teleport(x + mag, y, z)

    def stop(self):
        # Stop robot after the movement is over.
        vel_msg = Twist()

        vel_msg.linear.x = 0
        vel_msg.linear.y = 0
        vel_msg.linear.z = 0
        vel_msg.angular.x = 0
        vel_msg.angular.y = 0
        vel_msg.angular.z = 0

        self.velocity_publisher.publish(vel_msg)

    def setLinearVelocity(self, u):
        """
        Sets linear velocity of turtle in the x axis to control signal, u
        """

        vel_msg = Twist()

        vel_msg.linear.x = u
        vel_msg.linear.y = 0
        vel_msg.linear.z = 0
        
        self.velocity_publisher.publish(vel_msg)

    def getGoalPose(self, x, y):
        # Create and return goal_pose object (hint: Pose())
        goal_pose = Pose()
        goal_pose.x = x
        goal_pose.y = y
        return goal_pose

    def getTime(self, start):
        now = rospy.get_rostime()
        curTime  = now.secs - start.secs
        return curTime

    def getError(self, goalX, robotX):
        """
        Returns the error between the goal x position and current x position
        """
        return goalX - robotX 

    def move2goal(self, x, y):
        goal_pose = self.getGoalPose(x, y)
        start = rospy.get_rostime()
        linearVelocity = 1
        Kp = 0.1
        Kd = 0.0
        Ki = 0.0

        self.pid.setKp(Kp)
        self.pid.setKd(Kd)
        self.pid.setKi(Ki)

        while abs(linearVelocity) > 0:

            # Get error
            error = self.getError(goal_pose.x, self.pose.x)

            # Update the PID controller and get the PID's output control signal
            u = self.pid.update(error)

            rospy.loginfo("X: %f, Time: %i, u: %f", self.pose.x, self.getTime(start), u)

            # Update linearVelocity to equal your control signal
            self.setLinearVelocity(u)
           
            linearVelocity = round(u, 4)
            
            self.clear_background()
            self.rate.sleep()
        
        self.stop()
        now = rospy.get_rostime()
        compTime = now.secs - start.secs
        rospy.loginfo("Total time: %i", compTime)

        # If we press control + C, the node will stop.
        rospy.spin()

if __name__ == '__main__':
    try:
        robot = TurtleBot()
        robot.turtle2_teleport(0,5,0)
        robot.move2goal(5,5)
    except rospy.ROSInterruptException:
        pass