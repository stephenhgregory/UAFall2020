## Results
While I've implemented all the parts of a proper PID controller (proportional control, integral control, and derivative control), I've found that the best results in this experiment are obtained when the integral and derivative controllers are turned off (their respective constants, Kd, and Ki, are set to 0).
These results are shown in [this](varying_kd_results.png) chart, and [this](carying_ki_results.png) chart. 

When turning "on" the derivative controller, I find that the position of the turtle simply oscillates around the goal value at a steadily increasing amplitude over time. 
In fact, the best results come from turning this portion of the PID control off completely, by setting Kd to 0.

When turning "on" the integral controller, I find that the position of the turtle oscillates around the goal value, similar to the effect garnered by the derivative controller. 
However, this effect is more dramatic, as the turtle will tend to "overshoot" the goal position, and then "hover" at an overshot position, before bouncing back in the other direction, where it again overshoots the goal position and repeats this process.
This is most likely due to the integral being "stored up" over time, and that "stored up" value conflicts with the proportional controller. 
This is what causes the "hovering" effect, as the proportional controller pulls the turtle back towards the goal position after an overshoot, while the integral controller applies an inverse control signal which is "saved up" from the time that the turtle spent on the other side of the goal position.

**NOTE:** Blank bars in [this](varying_ki_results.png) chart, analyzing different values for Kp, signify a **divergent** result, wherein the turtle never reached the goal position within 360 seconds. 
