# Contains implementation of a PID controller

class PID:

    def __init__(self, Kp=1, Kd=0, Ki=0, derivator=0, integrator=0, integrator_max = 100, integrator_min = -100):

        self.Kp = Kp
        self.Kd = Kd
        self.Ki = Ki
        self.derivator = derivator
        self.integrator = integrator
        self.integrator_max = integrator_max
        self.integrator_min = integrator_min

        self.set_point = 0.0
        self.error = 0.0


    def update(self, error):
        """
        Calculates PID output for a given error, and updates the state of the PID controller
        """
        # Get the error
        self.error = error

        # Get the proportional factor of the PID control
        self.proportionalFactor = self.Kp * self.error

        # Get the derivative factor of the PID control, and update the derivator
        self.derivativeFactor = self.Kd * (self.error - self.derivator)
        self.derivator = self.error

        # Add the current error to the integrator
        self.integrator += self.error

        # Cap or peg the integrator to stay within its bounds
        if self.integrator > self.integrator_max:
            self.integrator = self.integrator_max
        elif self.integrator < self.integrator_min:
            self.integrator = self.integrator_min

        self.integralFactor = self.Ki * self.integrator

        PID_output = self.proportionalFactor + self.derivativeFactor + self.integralFactor

        return PID_output

    def setSetPoint(self, set_point):
        """
        Initialize the setpoint of the PID
        """
        self.set_point = set_point
        self.integrator = 0
        self.derivator = 0

    def setIntegrator(self, integrator):
        self.integrator = integrator

    def setDerivator(self, derivator):
        self.derivator = derivator

    def setKp(self, Kp):
        self.Kp=Kp

    def setKd(self, Kd):
        self.Kd=Kd

    def setKi(self, Ki):
        self.Ki=Ki

    def getSetPoint(self):
        return self.set_point

    def getError(self):
        return self.error

    def getIntegrator(self):
        return self.integrator

    def getDerivator(self):
        return self.derivator

    